package schedule;

/**
 *
 * @author BERDAQ
 */
import java.util.Calendar;

public class Schedule {

    public static void main(String[] args) {

       {Calendar cal = Calendar.getInstance();
        int z = cal.get(Calendar.DAY_OF_WEEK);
        Monday a = new Monday("Linear Algebra", "Differencial Equations", "Programming", "Differencial Equations");
        Tuesday b = new Tuesday("Physics", "Philosophy");
        Wednesday c = new Wednesday("Academical Writing", "Physics", "Programming", "English");
        Thurday d = new Thurday("Physics", "Philosophy", "Physical Education");
        Friday e = new Friday("Programming", "English", "Linear Algebra");
        switch (z - 1) {

            case 1:
                a.info();

                break;
            case 2:
                b.info();

                break;
            case 3:
                c.info();

                break;
            case 4:
                d.info();

                break;
            case 5:
                e.info();

                break;
            default:
                System.out.println("Have a rest!");
        }}}}
        //System.out.println(z);
   


