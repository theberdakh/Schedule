/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package schedule;

/**
 *
 * @author BERDAQ
 */
public class Tuesday {

    String first_subject;
    String second_subject;
 

    public Tuesday(String first_subject, String second_subject) {
        this.first_subject = first_subject;
        this.second_subject = second_subject;
        
    }

    void info() {
        System.out.println("1. " + this.first_subject);
        System.out.println("2. " + this.second_subject);
        

    }
}
