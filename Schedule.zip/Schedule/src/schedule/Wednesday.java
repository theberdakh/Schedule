/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package schedule;

/**
 *
 * @author BERDAQ
 */
public class Wednesday {

    String first_subject;
    String second_subject;
    String third_subject;
    String fourth_subject;

    public Wednesday(String first_subject, String second_subject, String third_subject, String fourth_subject) {
        this.first_subject = first_subject;
        this.second_subject = second_subject;
        this.third_subject = third_subject;
        this.fourth_subject = fourth_subject;
    }

    void info() {
        System.out.println("1. " + this.first_subject);
        System.out.println("2. " + this.second_subject);
        System.out.println("3. " + this.third_subject);
        System.out.println("4. " + this.fourth_subject);

    }
}
